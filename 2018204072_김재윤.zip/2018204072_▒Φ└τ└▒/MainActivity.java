package com.example.jaeyoon;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {   // Main 화면 class
    Button linux_move;   // linux 액티비티로 이동하는 버튼
    Button git_move;    // git 액티비티로 이동하는 버튼
    Button MCL_move;    // MyCommandList 액티비티로 이동하는 버튼
    MediaPlayer music;    // music 파일

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        linux_move = findViewById(R.id.linux_move);    // LINUX 버튼 화면에 set
        linux_move.setOnClickListener(new View.OnClickListener() {    // LINUX 버튼에 대한 이벤트 처리 시작
            @Override
            public void onClick(View view) {    // LINUX 버튼 클릭 이벤트
                Intent intent = new Intent(MainActivity.this, CommandsList.class);    // commands_list 액티비티로 넘겨주는 인텐트 생성
                intent.putExtra("id", linux_move.getText().toString());    // 인텐트에 id 값을 텍스트로 넣어주고
                startActivity(intent);    // 인텐트 실행
            }
        });

        git_move = findViewById(R.id.git_move);    // GIT 버튼 화면에 set
        git_move.setOnClickListener(new View.OnClickListener() {    // GIT 버튼에 대한 이벤트 처리 시작
            @Override
            public void onClick(View view) {    // GIT 버튼 클릭 이벤트
                Intent intent = new Intent(MainActivity.this, CommandsList.class);    // commands_list 액티비티로 넘겨주는 인텐트 생성
                intent.putExtra("id", git_move.getText().toString());    // 인텐트에 id 값을 텍스트로 넣어주고
                startActivity(intent);    // 인텐트 실행
            }
        });

        MCL_move = findViewById(R.id.MCL_move);    // MyCommandList 버튼 화면에 set
        MCL_move.setOnClickListener(new View.OnClickListener() {    // MyCommandList 버튼에 대한 이벤트 처리 시작
            @Override
            public void onClick(View view) {     // MyCommandList 버튼 클릭 이벤트
                Intent intent = new Intent(MainActivity.this, MyCommandList.class);   // my_command_list 액티비티로 넘겨주는 인텐트 생성
                startActivity(intent);    // 인텐트 실행
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {    // 옵션 메뉴
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.mainmenu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {    // 옵션 메뉴에 구성된 아이템 클릭에 대한 각각의 이벤트
        switch (item.getItemId()) {
            case R.id.menu1:    // 첫번째 옵션 study music을 클릭한 경우
                if (music != null && music.isPlaying()) {
                    music.pause();
                } else if (music == null) {
                    music = music.create(MainActivity.this, R.raw.study);
                    music.start();
                    music.setLooping(true);
                } else {
                    music.start();
                    music.setLooping(true);
                }

            case R.id.menu2:    // 두번째 옵션 memory music을 클릭한 경우
                if (music != null && music.isPlaying()) {
                    music.pause();
                } else if (music == null) {
                    music = music.create(MainActivity.this, R.raw.memory);
                    music.start();
                    music.setLooping(true);
                } else {
                    music.start();
                    music.setLooping(true);
                }
        }
        return super.onOptionsItemSelected(item);
    }
}
