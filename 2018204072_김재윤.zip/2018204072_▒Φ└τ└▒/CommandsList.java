package com.example.jaeyoon;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class CommandsList extends AppCompatActivity {
    ArrayList<CommandsItem> datas;
    ListView listview;    // 리스트뷰
    TextView page_name;   // Git or Linux를 알려주는 page_name 텍스트
    CommandsItemAdapter adapter;    // 어댑터
    DBHelper helper;    // 데이터베이스

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.commands_list);
        String id = getIntent().getStringExtra("id");    // MainActivt에서 보낸 id 값 get
        page_name = findViewById(R.id.page_name);    // Git or Linux 화면에 띄움
        datas = new ArrayList<>();    // 배열 생성
        listview = (ListView) findViewById(R.id.my_command_list);    // listview 액티비티에 set
        adapter = new CommandsItemAdapter();    // CommandsItemAdapter 클래스를 이용하여 어댑터 생성
        helper = new DBHelper(this);    // DBHelper 클래스를 이용하여 helper 생성

        switch (id) {    // MainActivty에서 받아온 id에 따라 배열에 각각 다른 아이템 추가
            case "Linux":    // Linux를 클릭한 경우
                page_name.setText("Linux");
                adapter.addItemToArrayList("mkdir", "디렉터리 생성");
                adapter.addItemToArrayList("rmdir", "디렉터리 삭제");
                adapter.addItemToArrayList("cd", "디렉터리 변경");
                adapter.addItemToArrayList("ls", "파일, 디렉터리 목록 보기");
                adapter.addItemToArrayList("touch", "파일 생성");
                adapter.addItemToArrayList("cat", "파일 생성 및 내용 보기");
                adapter.addItemToArrayList("cp", "파일 복사");
                adapter.addItemToArrayList("rm", "파일 삭제");
                adapter.addItemToArrayList("mv", "파일 또는 디렉터리 이름 변경 및 이동");
                adapter.addItemToArrayList("chmod", "접근 권한 변경");
                adapter.addItemToArrayList("chown", "파일 소유자 변경");
                adapter.addItemToArrayList("chgrp", "파일 그룹명 변경");
                adapter.addItemToArrayList("umask", "자동 사용권한 부여");
                adapter.addItemToArrayList("vi", "Vim 편집기 실행");
                adapter.addItemToArrayList("file", "파일 종류 확인");
                adapter.addItemToArrayList("wc", "문자 및 문자열 개수 구하기");
                adapter.addItemToArrayList("cmp", "파일 비교");
                adapter.addItemToArrayList("comm", "파일 비교");
                adapter.addItemToArrayList("diff", "파일 비교");
                adapter.addItemToArrayList("cut", "열의 추출");
                adapter.addItemToArrayList("paste", "열의 결합");
                adapter.addItemToArrayList("sort", "파일 정렬");
                adapter.addItemToArrayList("split", "파일 분할");
                adapter.addItemToArrayList("grep", "문자열 패턴 검색");
                adapter.addItemToArrayList("find", "파일 검색");
                adapter.addItemToArrayList("tar", "묶음과 압축");
                adapter.addItemToArrayList("ps", "프로세스 목록 보기");

                listview.setAdapter(adapter);
                listview.smoothScrollToPosition(0);
                adapter.notifyDataSetChanged();
                break;


            case "Git":    // Git을 클릭한 경우
                page_name.setText("G i t");
                // 어댑터에 명령어 추가
                adapter.addItemToArrayList("init", "저장소 생성");
                adapter.addItemToArrayList("add", "저장소에 파일 추가");
                adapter.addItemToArrayList("commit", "저장소에 수정 내역 제출");
                adapter.addItemToArrayList("status", "저장소 상태 확인");
                adapter.addItemToArrayList("branch", "브랜치 생성");
                adapter.addItemToArrayList("checkout", "브랜치 이동");
                adapter.addItemToArrayList("merge", "master 브랜치로 병합");
                adapter.addItemToArrayList("clone", "원격 > 로컬 복사");
                adapter.addItemToArrayList("remote", "로컬 > 원격 연결");
                adapter.addItemToArrayList("push", "로컬 > 원격 내용을 보내기");
                adapter.addItemToArrayList("fetch", "원격 > 로컬 commit 가져오기");
                adapter.addItemToArrayList("pull", "원격 > 로컬 내용 가져오기");

                listview.setAdapter(adapter); // 리스트뷰에 어댑터를 set한다
                listview.smoothScrollToPosition(0);
                adapter.notifyDataSetChanged();
                break;
        }
        // 리스트 뷰의 버튼 클릭 이벤트
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                CommandsItem item = (CommandsItem) adapter.getItem(i);
                Intent intent = new Intent(CommandsList.this, Explanation.class);  // CommandList > Explanation로의 인텐트 생성
                intent.putExtra("position", i);  // 인텐트에 position 값 담고
                intent.putExtra("command",item.getCommand());  // 인텐트에 command 담고
                intent.putExtra("explanation",item.getExplanation());  // 인텐트에 explanation 담고
                intent.putExtra("page_name",page_name.getText().toString());  // 인텐트에 page_name 담고
                startActivity(intent);   // 인텐트 실행
            }
        });
        // 리스트 뷰의 버튼 롱클릭 이벤트
        listview.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, long l) {
                Intent intent = new Intent(CommandsList.this, MyCommandList.class);    // CommandList > MyCommandList로의 인텐트 생성
                intent.putExtra("page_name",page_name.getText().toString());    // 인텐트에 page_name 담고

                AlertDialog.Builder dlg = new AlertDialog.Builder(CommandsList.this);    // 팝업 생성
                dlg.setTitle("즐겨찾기 추가")    // 텍스트 입력하여 팝업 set
                        .setMessage("추가 하시겠습니까 ?")    // 팝업 메시지로 "추가 하시겠습니까?" 출력
                        .setNegativeButton("취소", new DialogInterface.OnClickListener() {    // '취소' 누르는 경우 변화 없음
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                            }
                        })
                        .setPositiveButton("확인", new DialogInterface.OnClickListener() {    // '확인' 누르는 경우의 이벤트 처리
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                CommandsItem item = (CommandsItem) adapter.getItem(position);    // ListView에서 해당 포지션에 정보를 받아옴
                                String command = item.getCommand();    // command에 담기
                                String explanation = item.getExplanation();    // explanation에 담기
                                helper.insertItem(position, command, explanation, id);    // 데이터베이스에도 저장해야 함 (insertItem)
                                Toast.makeText(getApplicationContext(), "즐겨찾기에 등록 되었습니다.", Toast.LENGTH_SHORT).show();
                            }
                        }).show();
                return true;

            }
        });
    }
}