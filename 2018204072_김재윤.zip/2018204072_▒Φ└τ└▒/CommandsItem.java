package com.example.jaeyoon;
//어댑터에 추가 및 값에 접근 하기 위한 생성자
public class CommandsItem {
    String command;
    String explanation;


    public CommandsItem(String command, String explanation) {
        this.command=command;
        this.explanation=explanation;
    }

    public void setCommand(String command) {
        this.command = command;
    }

    public void setExplanation(String explanation) {
        this.explanation = explanation;
    }

    public String getCommand() {
        return command;
    }

    public String getExplanation() {
        return explanation;
    }
}