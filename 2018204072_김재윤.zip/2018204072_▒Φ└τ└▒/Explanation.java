package com.example.jaeyoon;


import android.content.Intent;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Explanation  extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.explanation);

        TextView 명령어 = (TextView) findViewById(R.id.명령어);
        TextView 설명 = (TextView) findViewById(R.id.설명);
        TextView gitorlinux = (TextView) findViewById(R.id.gitorlinux);
        TextView Text1 = (TextView) findViewById(R.id.Text1);
        Text1.setMovementMethod(new ScrollingMovementMethod());
        TextView Text2 = (TextView) findViewById(R.id.Text2);
        Text2.setMovementMethod(new ScrollingMovementMethod());

        Intent intent = getIntent();    // CommandsList로부터 받아온 intent   get
        명령어.setText(intent.getStringExtra("command"));
        설명.setText(intent.getStringExtra("explanation"));
        int cposition = intent.getIntExtra("position", 0);
        String cpagename = intent.getStringExtra("page_name");

        Intent intent1 = getIntent();    //MyCommandsList로부터 받아온 intent   get
        명령어.setText(intent1.getStringExtra("command"));
        설명.setText(intent1.getStringExtra("explanation"));
        int position = intent1.getIntExtra("position", 0);
        String id = intent1.getStringExtra("git_or_linux");

        if (id == null) {    // CommandsList에서 넘어온 경우 (id는 데이터베이스에 넘어가서 null값이다.)
            switch (cpagename) {    // CommandsList의 cpagename에 따른 Set
                case "Linux":
                    String[] linux_explanation = getResources().getStringArray(R.array.Linux_Explanation);// 만들어 놓은 리소스파일에서 가져와서 배열에 저장
                    String[] linux_options = getResources().getStringArray(R.array.Linux_Options);
                    Text1.setText(linux_explanation[cposition]);
                    Text2.setText(linux_options[cposition]);
                    gitorlinux.setText("Linux");
                    break;

                case "G i t":
                    String[] git_explanation = getResources().getStringArray(R.array.Git_Explanation);
                    String[] git_options = getResources().getStringArray(R.array.Git_Options);
                    Text1.setText(git_explanation[position]);
                    Text2.setText(git_options[position]);
                    gitorlinux.setText("G i t");
                    break;

            }
        } else {    // MyCommandList에서 넘어오는 경우 DB에서 넘어온 id 값에 따른 Set
            switch (id) {
                case "Linux":
                    String[] linux_explanation = getResources().getStringArray(R.array.Linux_Explanation);
                    String[] linux_options = getResources().getStringArray(R.array.Linux_Options);
                    Text1.setText(linux_explanation[cposition]);
                    Text2.setText(linux_options[cposition]);
                    gitorlinux.setText("Linux");
                    break;

                case "Git":
                    String[] git_explanation = getResources().getStringArray(R.array.Git_Explanation);
                    String[] git_options = getResources().getStringArray(R.array.Git_Options);
                    Text1.setText(git_explanation[cposition]);
                    Text2.setText(git_options[cposition]);
                    gitorlinux.setText("Git");
                    break;

            }

        }
    }
}