package com.example.jaeyoon;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class CommandsItemAdapter extends BaseAdapter {
    ArrayList<CommandsItem> datas = new ArrayList<CommandsItem>();


    @Override
    public int getCount() {
        return datas.size();
    }

    @Override
    public Object getItem(int position) {
        return datas.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final Context context = parent.getContext();
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.commands_item,parent, false);   //리스트뷰 팽창
        }

        TextView text_command = (TextView) convertView.findViewById(R.id.text_command);
        TextView text_explanation = (TextView) convertView.findViewById(R.id.text_explanation);

        CommandsItem mydata = datas.get(position);
        // 명령어와 설명을 각 리스트뷰 항목에 set
        text_command.setText(mydata.getCommand());
        text_explanation.setText(mydata.getExplanation());
        this.notifyDataSetChanged();

        return convertView; // 변화된 뷰를 Return
    }

    public void addItemToArrayList(String command, String explanation){    //어댑터에 값을 추가하기 위한 함수
        CommandsItem mydata = new CommandsItem(command, explanation);     // CommandItem 객체 생성

        mydata.setCommand(command);
        mydata.setExplanation(explanation);
        datas.add(mydata);    //CommandItem 형 Arraylist에 명령어와 설명을 추가
        this.notifyDataSetChanged();
    }


};