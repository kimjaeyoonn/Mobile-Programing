package com.example.jaeyoon;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MyCommandList extends AppCompatActivity {
    private DBHelper dbHelper;
    ListView listview;
    private CommandsItemAdapter adapter;
    ArrayList<CommandsItem> data;
    DBHelper helper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.my_command_list);

        listview = (ListView) findViewById(R.id.my_command_list);

        helper = new DBHelper(this);
        adapter = new CommandsItemAdapter();
        dbHelper = new DBHelper(this);
        SQLiteDatabase Mcl = dbHelper.getReadableDatabase();

        Cursor cursor = Mcl.rawQuery("select * from mycommand", null);    // rawQuery를 활용한 cursor 생성

        while (cursor.moveToNext()) { // 커서가 끝날 때 까지 반복
            adapter.addItemToArrayList(cursor.getString(1), cursor.getString(2)); // cursor를 통해 어댑터에 값을 가져옴
        }

        listview.setAdapter(adapter); // 어댑터를 리스트뷰에 set해줌
        listview.smoothScrollToPosition(0);
        adapter.notifyDataSetChanged();

        // 리스트 뷰의 버튼 클릭 이벤트
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                CommandsItem item = (CommandsItem) adapter.getItem(i);
                Intent intent = new Intent(MyCommandList.this, Explanation.class);    // MyCommandList > Explanation로의 인텐트 생성
                intent.putExtra("command",item.getCommand());    // 인텐트에 command 담고
                intent.putExtra("explanation",item.getExplanation());    // 인텐트에 explanation 담고
                Cursor git_or_linux = dbHelper.getItem(item.getCommand());    // 해당 포지션의 커맨드로 db의 커서값을 가져옴

                while(git_or_linux.moveToNext()){    // git_or_linux가 move하는 동안
                    intent.putExtra("position", git_or_linux.getInt(0));    // 인텐트에 position 값 담고
                    intent.putExtra("git_or_linux", git_or_linux.getString(3));    // 인텐트에 git_or_linux 담고
                }
                startActivity(intent);
            }
        });
        // 리스트 뷰의 버튼 롱클릭 이벤트
        listview.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {    // 삭제에 대한 이벤트 처리
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, long l) {

                CommandsItem item = (CommandsItem) adapter.getItem(position);
                AlertDialog.Builder dlg = new AlertDialog.Builder(MyCommandList.this);    //
                dlg.setTitle("삭제")    // 텍스트 입력하여 팝업 set
                        .setMessage("삭제하시겠습니까 ?")    // 팝업 메시지로 "삭제 하시겠습니까?" 출력
                        .setNegativeButton("취소", new DialogInterface.OnClickListener() {    // "취소" 누르는 경우 변화 없음
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                            }
                        })
                        .setPositiveButton("확인", new DialogInterface.OnClickListener() {    // "확인" 누르는 경우의 이벤트 처리
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                                CommandsItem item = (CommandsItem) adapter.getItem(position);    // ListView에서 해당 포지션에 정보를 받아옴
                                String command = item.getCommand();
                                dbHelper.delete(command);    // DB에서 삭제
                                Toast.makeText(getApplicationContext(), "삭제되었습니다.", Toast.LENGTH_SHORT).show();
                                // 삭제 후 갱신을 위해 db에 접근하여 값들을 새로 어댑터에 가져오고 그 어댑터를 리스트뷰에 set해준다
                                adapter = new CommandsItemAdapter();
                                SQLiteDatabase Mcl = dbHelper.getReadableDatabase();
                                Cursor cursor = Mcl.rawQuery("select * from mycommand", null);

                                while (cursor.moveToNext()) {
                                    adapter.addItemToArrayList(cursor.getString(1), cursor.getString(2));
                                }

                                listview.setAdapter(adapter); // 리스트뷰에 어댑터를 set해준다
                                adapter.notifyDataSetChanged();
                            }
                        }).show();//팝업 및 대화상자 표시
                return true;
            }
        });
    }
}