package com.example.jaeyoon;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "MyCommandlist.db";
    public static final String MYCOMMAND_TABLE_NAME = "mycommand";
    public static final String MYCOMMAND_COLUMN_ID="id";
    public static final String MYCOMMAND_COLUMN_COMMAND="command";
    public static final String MYCOMMAND_COLUMN_EXPLANATION="explanation";
    public static final String MyCOMMAND_COULMN_GITORLINUX="git_or_linux";

    public DBHelper(Context context){super(context,DATABASE_NAME, null, 1);}
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        // 데이터베이스가 생성이될 때 호출
        //데이터베이스 > 테이블 > 컬럼 > 값 순서
        // db 생성
        sqLiteDatabase.execSQL("create table if not exists mycommand " + "(id integer primary key, command text not null, explanation text not null, git_or_linux text not null)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        onCreate(sqLiteDatabase);
    }



    // INSERT 문 (즐겨찾기에 추가된 명령어를 DB에 넣는다.)
    public void insertItem(int position, String command, String explanation, String git_or_linux){
        SQLiteDatabase mycommand = this.getWritableDatabase(); //쓰기 모드로 db접근한다
        ContentValues contentValues =new ContentValues();

        contentValues.put("id", position);
        contentValues.put("command",command);
        contentValues.put("explanation",explanation);
        contentValues.put("git_or_linux", git_or_linux);

        mycommand.insert("mycommand",null, contentValues); // 추가된 항목을 db에 추가
    }

    // DELETE 문 (즐겨찾기 명령어를 제거한다.)
    public void delete(String command){
        SQLiteDatabase mycommand = getWritableDatabase();//쓰기 모드로 db접근한다
        mycommand.execSQL("DELETE FROM mycommand WHERE command = '" + command + "'");
    }

    public Cursor getItem(String command){ // 명령어 종류에 따라 git의 명령어인지 linux의 명령어인지 파악가능
        SQLiteDatabase mycommand = getReadableDatabase();
        Cursor git_or_linux= mycommand.rawQuery("select * from mycommand where command = '" + command + "'",null);
        return git_or_linux; // 해당 커서를 리턴
    }
}